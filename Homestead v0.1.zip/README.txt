Homestead v0.1
Mitchell Garrett
May 2021

Made for the Console Game Jam (https://itch.io/jam/console-jam)
Written in C using PDCurses (https://pdcurses.org/)